

        
// PIC24FJ256GB108 Configuration Bit Settings

// 'C' source line config statements

// CONFIG3
#pragma config WPFP = WPFP511           // Write Protection Flash Page Segment Boundary (Highest Page (same as page 170))
#pragma config WPDIS = WPDIS            // Segment Write Protection Disable bit (Segmented code protection disabled)
#pragma config WPCFG = WPCFGDIS         // Configuration Word Code Page Protection Select bit (Last page(at the top of program memory) and Flash configuration words are not protected)
#pragma config WPEND = WPENDMEM         // Segment Write Protection End Page Select bit (Write Protect from WPFP to the last page of memory)

// CONFIG2
#pragma config POSCMOD = HS             // Primary Oscillator Select (HS oscillator mode selected)
#pragma config DISUVREG = ON            // Internal USB 3.3V Regulator Disable bit (Regulator is enabled)
#pragma config IOL1WAY = ON             // IOLOCK One-Way Set Enable bit (Write RP Registers Once)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSCO functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Both Clock Switching and Fail-safe Clock Monitor are disabled)
#pragma config FNOSC = PRIPLL           // Oscillator Select (Primary oscillator (XT, HS, EC) with PLL module (XTPLL,HSPLL, ECPLL))
#pragma config PLL_96MHZ = ON           // 96MHz PLL Disable (Enabled)
#pragma config PLLDIV = DIV3            // USB 96 MHz PLL Prescaler Select bits (Oscillator input divided by 3 (12MHz input))
#pragma config IESO = OFF               // Internal External Switch Over Mode (IESO mode (Two-speed start-up)disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator functions are shared with PGEC2/PGED2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#define SYS_FREQ 32000000L
#define FCY SYS_FREQ/2
#include <libpic30.h>
#include "usb/usb.h"

volatile int negy = 4;
volatile double masodperc = 0;
volatile int igazhamis=0;
volatile int ketkez=0;

char readBuffer[64]; // fogadott adatok
char writeBuffer[64]; // k�ldend� adatok

int sor_hossz = 0; // h�ny karakter �rkezett be eddig?
char sor[100]; // eddig be�rkezett karakterek

void USB_comm_task() {
    // ha nincs konfigur�lva az USB, akkor nincs tov�bbi teend�
    if( USBGetDeviceState() < CONFIGURED_STATE )
        return;

    // ha fel van f�ggesztve az USB kommunik�ci�, akkor nincs tov�bbi teend�
    if(USBIsDeviceSuspended())
        return;

    // 1s-k�nt potm�ter �rt�k�nek kik�ld�se
    if(USBUSARTIsTxTrfReady()){

        
        // v�lasz k�ld�se
        sprintf(writeBuffer, "%0.2f\r\n", masodperc);
        putsUSBUSART(writeBuffer);
        
       
    }
    
    
    // adatk�ld�s service h�v�sa
    CDCTxService();
}


// LEDek �s nyom�gombok
#define LED1 _LATG6
#define LED2 _LATG7
#define LED3 _LATG8
#define LED4 _LATG9
#define LEDR _LATD15
#define LEDG _LATF4
#define LEDB _LATF5
#define REZGES _RD11
#define BAL _RD9
#define JOBB _RD14
#define SW1 !_RC1
#define SW2 !_RC3
#define SW3 !_RE8
#define SW4 !_RE9

// LCD bek�t�se
#define LCD_RS   _LATG0 // register select (0=utas�t�s, 1=adat)
#define LCD_RW   _LATG1 // read/write (0=�r�s, 1=olvas�s)
#define LCD_E    _LATF1 // enable (parancs kiad�sa)
#define LCD_DATA LATE   // adatbusz (0..7 bitek)
#define LCD_BF   _RE7   // busy flag (adatbusz legmagasabb bitje)

// karakter k�ld�se az LCD-re (c: adat; rs: 0=utas�t�s, 1=adat)
void lcdWrite(uint8_t c, uint8_t rs){
    // el�k�sz�t�s a busy flag beolvas�sra
    TRISE |= 0x00ff; // adatl�bak bemenetek
    LCD_RW = 1; // olvas�s
    LCD_RS = 0; // utas�t�s �zemm�d

    // v�rakoz�s, am�g az eszk�z foglalt
    uint8_t BF; // beolvasott flag
    do {
        // busyflag olvas�sa
        LCD_E = 1; // enable bit magas
        Nop(); Nop(); Nop(); // LCD vez�rl�re v�rakoz�s
        BF = LCD_BF; // busy flag beolvas�sa
        LCD_E = 0; // enable alacsony
    } while(BF);

    // el�k�sz�t�s k�ld�sre
    TRISE &= ~0x00ff; // adatl�bak kimenetek
    LCD_RW = 0; // �r�s
    LCD_RS = rs; // utas�t�s/adat �zemm�d
    LCD_DATA = (LCD_DATA & ~0x00ff) | c; // adat k�ld�se

    // k�ld�s
    LCD_E = 1; // enable bit magas
    Nop(); Nop(); Nop(); // LCD vez�rl�re v�rakoz�s
    BF = LCD_BF; // busy flag beolvas�sa
    LCD_E = 0; // enable alacsony
}

// LCD makr�k
#define lcdPutChar(c) lcdWrite(c, 1)   // karakter k�ld�se
#define lcdPutCmd(d)  lcdWrite(d, 0)   // utas�t�s k�ld�se
#define lcdClear()    lcdWrite(0x01,0) // LCD t�rl�se
#define lcdGoHome()   lcdWrite(0x02,0) // LCD k�ld�se az 1. sorba
#define lcdGo2Row()   lcdWrite(0xC0,0) // LCD k�ld�se a 2. sorba

// LCD inicializ�l�sa
void lcdInit(){
    // I/O ir�nyok be�ll�t�sa
    _TRISG0 = 0; // RS kimenet
    _TRISG1 = 0; // RW kimenet
    _TRISF1 = 0; // E kimenet
    TRISE &= ~0x00ff; // D0..7 kimenet

    // kezdeti �rt�kek be�ll�t�sa
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_E = 0;
    
    // be�ll�t�sok
    __delay_ms(50);
    lcdPutCmd(0x38); // 8 bit, 2 row, 0-�s karakterk�szlet
    lcdPutCmd(0x08); // display off , cursor off, blinking off
    lcdPutCmd(0x01); // k�perny� t�rl�se, kurzor alaphelyzetbe �ll�t�sa
    lcdPutCmd(0x06); // automatikus inkrement�l�s, nem l�pteti a kijelz�t
    lcdPutCmd(0x0C); // display on , cursor off, blinking off
    __delay_ms(3);
}

// egy sztring ki�r�sa az LCD-re
void lcdPutStr(char *str){
    while (*str) {
        switch(*str) { // magyar karakterek cser�je a felt�lt�ttre
            case '�': lcdPutChar(0x00); break;
            case '�': lcdPutChar(0x01); break;
            case '�': lcdPutChar(0x02); break;
            case '�': lcdPutChar(0x03); break;
            case '�': lcdPutChar(0x04); break;
            case '�': lcdPutChar(0x05); break;
            case '�': lcdPutChar(0x06); break;
            case '�': lcdPutChar(0x07); break;
            case '�': lcdPutChar(0xef); break;
            case '\n': lcdGo2Row(); break;
            default: lcdPutChar(*str); break;
        }
        str++;
    }
}

char LCD[34]; // 16 karakter + '\n' + 16 karakter + '\0'

// magyar �kezetes karakterek
const unsigned char hu_char[] = {
    0x02,0x04,0x0E,0x01,0x0F,0x11,0x0F,0x00, // �
    0x02,0x04,0x0E,0x11,0x1F,0x10,0x0E,0x00, // �
    0x02,0x04,0x0C,0x04,0x04,0x04,0x0E,0x00, // �
    0x02,0x04,0x0E,0x11,0x11,0x11,0x0E,0x00, // �
    0x02,0x04,0x11,0x11,0x11,0x13,0x0D,0x00, // �
    0x0A,0x00,0x11,0x11,0x11,0x13,0x0D,0x00, // �
    0x05,0x0A,0x11,0x11,0x11,0x13,0x0D,0x00, // �
    0x05,0x0A,0x0E,0x11,0x11,0x11,0x0E,0x00  // �
};
// magyar �kezetes karakterek felt�lt�se a CGRAM-ba
void lcdLoadHuChars(void) {
    int i;
    lcdPutCmd(0x40); // kurzor a CGRAM elej�re (0. char)
    for(i=0; i<64; i++) {
        lcdPutChar(hu_char[i]);// karaktert�bla felt�lt�se
    }
    lcdPutCmd(0x80); // kurzor vissza, a DDRAM elej�re
}




void timer_10Hz_init(){
    // Timer1 konfigur�l�sa
    T1CONbits.TON = 0; // timer kikapcsol�sa
    T1CONbits.TCS = 0; // �rajelforr�s: FCY -> 16MHz
    T1CONbits.TGATE = 0; // gated �zemm�d tilt�sa -> minden �rajelre sz�mol
    T1CONbits.TCKPS = 0b11; // 256-os el�oszt� -> 62500Hz
    PR1 = 624; // peri�dus be�ll�t�sa 
    TMR1 = 0; // sz�ml�l� null�z�sa
    
    // interrupt konfigur�l�sa
    _T1IP = 1; // 1-es priorit�s
    _T1IE = 1; // enged�lyez�s
    _T1IF = 0; // flag t�rl�s
    
    // �ra ind�t�sa
    T1CONbits.TON = 1;
}

volatile int szazad = 0;

void _ISR _T1Interrupt(){
    szazad++;
            
    // interrupt flag t�rl�se
    _T1IF = 0;
}

enum State_E {
    ST_INIT,
    ST_VALASZT,
    ST_REZEG,
    ST_KETKEZ,
    ST_REZEG_INIT,
    ST_REZEG_VISSZASZAMOL,
    ST_REZEG_MERES,
    ST_KETKEZ_MERES,
    ST_MERES_RENDBEN,
    ST_KETKEZ_VISSZASZAMOL,
    ST_KETKEZ_INIT
};


int main(){
    // System Clock postscaler be�ll�t�sa
    CLKDIVbits.CPDIV = 0; // 1-szeres oszt�s, 96MHz->96MHz
    // de ez ut�n m�g van egy 3-mas oszt�, a v�gleges SYS_FREQ ez�rt 32Mhz
    // v�rakoz�s PLL elk�sz�lt�ig
    while(!OSCCONbits.LOCK) Nop();
    // Watchdog timer ki
    RCONbits.SWDTEN = 0;
    
    // ki- �s bemenetek be�ll�t�sa
    _TRISG6 = 0; // LED1
    _TRISG7 = 0; // LED2
    _TRISG8 = 0; // LED3
    _TRISG9 = 0; // LED4
    _TRISD15 = 0; // LEDR
    _TRISF4 = 0; // LEDG
    _TRISF5 = 0; // LEDB
    _TRISC1 = 1; // SW1
    _TRISC3 = 1; // SW2
    _TRISE8 = 1; // SW3
    _TRISE9 = 1; // SW4
    
    //Rezges
    _TRISD11 = 1;
    
    //Ketkez
    _TRISD14 = 1;
    _TRISD9 = 1;
    
    // USB inicializ�l�sa �s v�rakoz�s sikeres csatlakoz�sra
    USBDeviceInit(); 
    USBDeviceAttach();
    
    // lcd inicializ�l�s
    lcdInit();
    lcdLoadHuChars();
    
    //Timer init
    timer_10Hz_init();
    
    
   
    // kezdeti �llapot�tmenet
    lcdPutStr("Projekt");
    __delay_ms(200);
    enum State_E State = ST_INIT;
    
    // f�ciklus
    while(1){
        switch(State){
            case ST_INIT:
                
                
                State = ST_VALASZT;
                TMR1=0;
                szazad=0;
                
                
                break;
                
            case ST_VALASZT:
                if(szazad>=200)
                {
                    if(igazhamis==0)
                    {
                        lcdClear();
                        lcdPutStr("V�lassz m�dot!\n");
                        igazhamis=1;
                        szazad=0;
                        TMR1=0;
                        continue;
                    }
                    if(igazhamis==1)
                    {
                        lcdClear();
                        lcdPutStr("SW1:Rezg�s\nSW2:K�tkezes");
                        igazhamis=0;
                        szazad=0;
                        TMR1=0;
                        continue;
                    }
                }
                __delay_ms(10);
                if(SW1){
                    __delay_ms(10);
                    lcdClear();
                    lcdPutStr("Rezg�s\nSW4: OK SW3:BACK");
                    State=ST_REZEG;
                    break;
                }        

                if(SW2){
                   __delay_ms(5);
                    lcdClear();
                    lcdPutStr("2 kezes\nSW4: OK SW3:BACK");
                    State=ST_KETKEZ;
                    break;
                }
                break;
                
            case ST_REZEG:
                    if(SW4){
                        __delay_ms(100);
                        while(SW4) __delay_ms(10);
                        TMR1 = 0; // �ra null�z�sa
                        szazad = 0;
                        State=ST_REZEG_INIT;
                        lcdClear();
                        lcdPutStr("START: SW4");
                        LED1 = 0;
                        LED2 = 0;
                        LED3 = 0;
                        LED4 = 0;
                        break;
                    }
                    if(SW3){
                        __delay_ms(5);
                        State=ST_VALASZT;
                        lcdClear();
                        lcdPutStr("V�lassz m�dot!\n");
                        igazhamis=1;
                        szazad=0;
                        TMR1=0;
                        
                        break;
                    }
                break;
            
            
            case ST_REZEG_INIT:
                ketkez=0;

                if(SW4){     
                 __delay_ms(100);
                while(SW4) Nop();
                TMR1 = 0; // �ra null�z�sa
                szazad = 0;
                State=ST_REZEG_VISSZASZAMOL;
                negy = 4;
                lcdClear();
                sprintf(LCD,"%d",negy);
                lcdPutStr(LCD);
                }
                break;
                
            case  ST_REZEG_VISSZASZAMOL:
                if(szazad == 100){
                    szazad = 0;
                    negy--;
                    lcdClear();
                    sprintf(LCD,"%d",negy);
                    lcdPutStr(LCD);
                }
                if(negy == 0){
                    LED1 = 1;
                    LED2 = 1;
                    LED3 = 1;
                    LED4 = 1;
                    TMR1 = 0; // �ra null�z�sa
                    szazad = 0;
                    State=ST_REZEG_MERES;
                    lcdClear();
                    lcdPutStr("START");
                }
                break;
                
            case ST_REZEG_MERES:
                if(REZGES){
                    lcdClear(); 
                    masodperc = (double)szazad/100;
                    sprintf(LCD,"%0.2f\nOK:SW1 DEL:SW2",masodperc);
                    lcdPutStr(LCD);
                    State=ST_MERES_RENDBEN;
                }
                break;
            case ST_MERES_RENDBEN:
                __delay_ms(10);
                if(SW1){
                    while(SW1) Nop();
                    __delay_ms(10);
                    lcdClear();
                    USB_comm_task();
                    State=ST_INIT;
                    LED1 = 0;
                    LED2 = 0;
                    LED3 = 0;
                    LED4 = 0;
                    lcdClear();
                    lcdPutStr("V�lassz m�dot!\n");
                    igazhamis=1;
                    szazad=0;
                    TMR1=0;
                }
                
                if(SW2){
                    if(ketkez==0)
                    {
                    lcdClear();
                    lcdPutStr("Rezg�s\nSW4: OK SW3:BACK");
                    State=ST_REZEG;   
                    LED1 = 0;
                    LED2 = 0;
                    LED3 = 0;
                    LED4 = 0;
                    }
                    if(ketkez==1)
                    {
                    lcdClear();
                    lcdPutStr("K�tk�z\nSW4: OK SW3:BACK");
                    State=ST_KETKEZ;   
                    LED1 = 0;
                    LED2 = 0;
                    LED3 = 0;
                    LED4 = 0;
                    
                    }
                }
                
                break;
                
                
            case ST_KETKEZ:
                    ketkez=1;
                    if(SW4){
                         __delay_ms(10);
                        while(SW4) Nop();

                        TMR1 = 0; // �ra null�z�sa
                        szazad = 0;
                        State=ST_KETKEZ_INIT;
                        lcdClear();
                        LED1 = 0;
                        LED2 = 0;
                        LED3 = 0;
                        LED4 = 0;
                        lcdClear();
                        lcdPutStr("Kezet le!");
                        break;
                    }
                    if(SW3){
                        __delay_ms(5);
                        State=ST_VALASZT;
                        lcdClear();
                        lcdPutStr("V�lassz m�dot!\n");
                        igazhamis=1;
                        szazad=0;
                        TMR1=0;
                        break;
                    }
                break;
            case ST_KETKEZ_INIT:
               
                if(BAL&JOBB)
                {
                    State=ST_KETKEZ_VISSZASZAMOL;
                    lcdClear();
                    lcdPutStr("Start:\nKezet fel!");
                }
                
                break;
            case ST_KETKEZ_VISSZASZAMOL:
                if(!BAL&&!JOBB)
                {
                    
                    LED1 = 1;
                    LED2 = 1;
                    LED3 = 1;
                    LED4 = 1;
                    TMR1 = 0; // �ra null�z�sa
                    szazad = 0;
                    State=ST_KETKEZ_MERES;
                    lcdClear();
                    lcdPutStr("START");
                }
                
                break;
                
            case ST_KETKEZ_MERES:
                if(BAL&&JOBB){
                    lcdClear(); 
                    masodperc = (double)szazad/100;
                    sprintf(LCD,"%0.2f\nOK:SW1 DEL:SW2",masodperc);
                    lcdPutStr(LCD);
                    State=ST_MERES_RENDBEN;
                }
                break; 
  

        }
    }
    
    return 0;
}

        
      
