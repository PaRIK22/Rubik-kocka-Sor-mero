import os; os.system('cls');
import serial;
import csv;

file_nev = 'MeresiEredmenyek.csv'

umogi = serial.Serial(port='COM3',baudrate=9600, timeout=0.1) #baudrate, timeout arduinora van, ezt megkell nézni umogira
futas = 1

while(futas):
    uzenet_beolvas = umogi.readline() #byteokat olvas be a portról
    uzenet_beolvas = uzenet_beolvas.decode('utf-8') #byteok -> string ez a sor lehet nem kell?

    if (len(uzenet_beolvas) > 0):
        print("A mért idő: "+ uzenet_beolvas + '\n')
        futas = 0
        with open(file_nev, mode="a", newline='', encoding="utf-8") as file:
            writer = csv.writer(file)
            writer = writer.writerow([uzenet_beolvas])




